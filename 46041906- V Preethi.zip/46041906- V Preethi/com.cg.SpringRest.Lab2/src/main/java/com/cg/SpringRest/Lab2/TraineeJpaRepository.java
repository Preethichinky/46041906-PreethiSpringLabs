package com.cg.SpringRest.Lab2;

import org.springframework.data.repository.CrudRepository;

public interface TraineeJpaRepository extends CrudRepository<Trainee, Integer> {
}